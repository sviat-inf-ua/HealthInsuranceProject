package com.service;

import com.entity.Location;

public interface LocationService extends CrudService<Location, Integer>{

}
