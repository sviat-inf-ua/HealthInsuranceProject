package com.service;

import com.entity.DoctorType;

public interface DoctorTypeService extends CrudService<DoctorType, Integer>{

}
