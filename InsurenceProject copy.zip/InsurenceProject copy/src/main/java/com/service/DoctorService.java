package com.service;

import com.entity.Doctor;

public interface DoctorService extends CrudService<Doctor, Integer> {

}
