package com.dao;

import com.entity.Location;

public interface LocationDao extends CrudDao<Location, Integer>{

}
