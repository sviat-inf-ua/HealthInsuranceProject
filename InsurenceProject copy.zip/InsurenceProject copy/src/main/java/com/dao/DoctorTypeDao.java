package com.dao;

import com.entity.DoctorType;

public interface DoctorTypeDao extends CrudDao<DoctorType, Integer>{

}
