package com.dao;

import com.entity.Doctor;

public interface DoctorDao extends CrudDao<Doctor, Integer>{

}
